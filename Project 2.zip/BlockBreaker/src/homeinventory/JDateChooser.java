package homeinventory;

import java.awt.Dimension;
import java.beans.PropertyChangeListener;
import java.util.Date;

public class JDateChooser {

	public void setPreferredSize(Dimension dimension) {
		// TODO Auto-generated method stub
		
	}

	public void addPropertyChangeListener(PropertyChangeListener propertyChangeListener) {
		// TODO Auto-generated method stub
		
	}

	public Date getDate() {
		// TODO Auto-generated method stub
		return null;
	}

	public void requestFocus() {
		// TODO Auto-generated method stub
		
	}

	public void setDate(Date stringToDate) {
		// TODO Auto-generated method stub
		
	}

}
